"""Reference cleaning and held-out model checks. Run from the workshop folder."""
from pathlib import Path
import json
import re
import numpy as np
import pandas as pd
from scipy.stats import pearsonr
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.dummy import DummyRegressor
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score
from xgboost import XGBRegressor

ROOT=Path(__file__).resolve().parents[1]
FAC=ROOT/'facilitator'

def clean(path):
    d=pd.read_csv(path,dtype=str,keep_default_na=False)
    d=d.apply(lambda col:col.str.strip())
    d=d.replace({'':np.nan,'NA':np.nan,'not recorded':np.nan})
    def parse_date(v):
        if pd.isna(v): return pd.NaT
        for fmt in ['%Y-%m-%d','%m/%d/%Y','%Y/%m/%d','%b %d, %Y']:
            try: return pd.to_datetime(v,format=fmt)
            except (ValueError,TypeError): pass
        return pd.NaT
    d['date']=d.date.map(parse_date)
    d.loc[~d.date.between('2025-01-01','2025-12-31'),'date']=pd.NaT
    d['site']=d.site.str.title()
    d['session_type']=d.session_type.str.lower().str.capitalize()
    d['status']=d.status.str.lower().replace({'complete':'completed','canceled':'cancelled','no show':'no-show'}).str.capitalize()
    for col in ['volunteer_hours','participant_count','participant_satisfaction','participant_problem_addressed']:
        s=d[col].str.replace(r'\s*(hrs|people|/5|%)$','',regex=True)
        d[col]=pd.to_numeric(s,errors='coerce')
    for col,lo,hi in [('volunteer_hours',0,80),('participant_count',0,60),
                     ('participant_satisfaction',1,5),('participant_problem_addressed',0,100)]:
        d.loc[~d[col].between(lo,hi),col]=np.nan
    d.loc[d.participant_count.mod(1).ne(0),'participant_count']=np.nan
    complete=d.status.eq('Completed')
    d.loc[complete & d.participant_count.eq(0),'participant_count']=np.nan
    # Quarantine contradictory attendance; never infer an unknown count from the answer key.
    d.loc[~complete & d.participant_count.gt(0),'participant_count']=np.nan
    d.loc[~complete,['participant_satisfaction','participant_problem_addressed']]=np.nan
    return d

def run():
    d=clean(ROOT/'participants'/'telehealth_sessions_2025.csv')
    d.to_csv(FAC/'telehealth_sessions_cleaned.csv',index=False,date_format='%Y-%m-%d')
    c=d[d.status.eq('Completed')].copy()
    c['hours_per_participant']=c.volunteer_hours/c.participant_count.replace(0,np.nan)
    pairs=[('volunteer_hours','participant_count'),('hours_per_participant','participant_satisfaction'),
           ('participant_satisfaction','participant_problem_addressed')]
    correlations=[]
    for x,y in pairs:
        a=c[[x,y]].dropna(); r,p=pearsonr(a[x],a[y])
        correlations.append(dict(x=x,y=y,n=len(a),r=float(r),p_value=float(p)))
    model=c.dropna(subset=['date','participant_satisfaction']).copy()
    model['month']=model.date.dt.month
    features=['site','session_type','month','volunteer_hours','participant_count','hours_per_participant']
    nums=['month','volunteer_hours','participant_count','hours_per_participant']
    cats=['site','session_type']
    train=model.date.lt('2025-10-01'); test=~train
    estimators={
        'Mean baseline':DummyRegressor(strategy='mean'),
        'Ridge regression':Ridge(alpha=8),
        'Random Forest':RandomForestRegressor(n_estimators=350,max_depth=7,min_samples_leaf=6,random_state=31,n_jobs=1),
        'XGBoost':XGBRegressor(n_estimators=220,max_depth=3,learning_rate=.035,min_child_weight=8,
                              subsample=.85,colsample_bytree=.9,reg_lambda=8,random_state=31,n_jobs=1,objective='reg:squarederror')}
    scores=[]
    for name,est in estimators.items():
        pre=ColumnTransformer([
            ('num',Pipeline([('impute',SimpleImputer(strategy='median')),('scale',StandardScaler())]),nums),
            ('cat',OneHotEncoder(handle_unknown='ignore',sparse_output=False),cats)])
        pipe=Pipeline([('prepare',pre),('model',est)])
        pipe.fit(model.loc[train,features],model.loc[train,'participant_satisfaction'])
        pred=pipe.predict(model.loc[test,features])
        scores.append(dict(model=name,train_n=int(train.sum()),test_n=int(test.sum()),
                           MAE=float(mean_absolute_error(model.loc[test,'participant_satisfaction'],pred)),
                           R2=float(r2_score(model.loc[test,'participant_satisfaction'],pred))))
    # All site summaries use observable cleaned values, not hidden reference values.
    site=[]
    for name,g in d.groupby('site'):
        a=g[g.status.eq('Completed')]
        site.append(dict(site=name,scheduled=len(g),completed=len(a),completion_pct=round(100*len(a)/len(g),1),
                         attendance=int(a.participant_count.sum()),attendance_recorded=int(a.participant_count.notna().sum()),
                         satisfaction_mean=round(a.participant_satisfaction.mean(),2),
                         satisfaction_recorded=int(a.participant_satisfaction.notna().sum()),
                         satisfaction_missing_pct=round(100*a.participant_satisfaction.isna().mean(),1),
                         addressed_session_mean_pct=round(a.participant_problem_addressed.mean(),1)))
    pd.DataFrame(site).to_csv(FAC/'site_summary.csv',index=False)
    monthly=d.assign(month=d.date.dt.month).groupby(['site','month']).agg(scheduled=('session_id','size'),
            satisfaction=('participant_satisfaction','mean'),participants=('participant_count','sum'),hours=('volunteer_hours','sum')).reset_index()
    monthly.to_csv(FAC/'monthly_summary.csv',index=False)
    pd.DataFrame(scores).to_csv(FAC/'model_validation.csv',index=False)
    pd.DataFrame(correlations).to_csv(FAC/'pearson_correlations.csv',index=False)
    result=dict(correlations=correlations,models=scores,sites=site,
                missing_after_cleaning=d.isna().sum().to_dict())
    (FAC/'validation_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__': run()
