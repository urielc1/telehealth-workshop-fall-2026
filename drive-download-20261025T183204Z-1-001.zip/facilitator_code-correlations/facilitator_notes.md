# Facilitator notes

Keep this folder separate from the materials distributed to participants.

## Dataset and exercise

The participant export contains exactly 600 unique scheduled sessions, nine fields, six fictional sites, and all twelve months of 2025. It has 504 completed sessions, 63 cancellations, and 33 no-shows after category normalization. The two feedback measures are separate: mean satisfaction on a 1–5 scale and the percentage of survey respondents whose main need was addressed.

The aim is to recommend two site visits using outreach, delivery reliability, staffing, and participant feedback. The intended primary choices are Eastbank and Hillcrest. Accept alternatives when participants support them with evidence and explain the tradeoff.

## Expected findings from the cleaned observed data

| Site | Scheduled | Completion rate | Mean satisfaction | Mean session problem-addressed percentage |
|---|---:|---:|---:|---:|
| Brookfield | 118 | 84.7% | 4.11 | 82.1% |
| Eastbank | 126 | 84.1% | 3.52 | 76.9% |
| Hillcrest | 88 | 71.6% | 3.38 | 65.4% |
| Lakeside | 72 | 90.3% | 4.05 | 85.2% |
| Maplewood | 94 | 92.6% | 4.04 | 82.4% |
| Riverside | 102 | 81.4% | 4.02 | 84.6% |

These are session-level means over available responses. They are not pooled patient-level estimates. `site_summary.csv` includes the feedback and attendance completeness denominators.

- **Eastbank: growing reach with deteriorating participant experience.** It has the most scheduled sessions and 1,680 recorded attendance instances. Mean satisfaction falls from 3.99 in Q1 to 3.13 in Q3, then 3.28 in Q4. Recorded attendance rises from 350 in Q1 to 561 in Q4 while recorded total volunteer hours are 144.50 and 138.25 respectively. These sums have missing entries and include different session mixes; ask students to compare like session types and available-case coverage before diagnosing a staffing problem. A visit could examine workload, scheduling, and support needs.
- **Hillcrest: delivery reliability and experience.** Its 71.6% completion rate is the lowest; mean satisfaction and mean problem-addressed percentage are also the lowest. Six of its 63 completed-session satisfaction scores are missing after cleaning. A visit could examine cancellations, participant access barriers, workflow, and feedback collection.
- **Brookfield: improvement over time.** Mean satisfaction rises from 3.88 in Q1 to 4.26 in Q4. Annual averages alone hide the improvement.
- **Lakeside: smaller reach does not imply poor performance.** It has the fewest scheduled sessions but a 90.3% completion rate and strong feedback. The data contains no local population or unmet-need denominator with which to establish under-reach.
- **Maplewood and Riverside:** provide comparison sites with different completion rates and service mixes. Riverside's 81.4% completion rate can justify a secondary discussion even though its feedback is stronger than the two intended priorities.

## Relationships built into the exercise

Staffing relative to attendance matters more than raw hours alone. The relationship has diminishing returns: more hours help under-supported sessions more than already well-supported sessions. Session types have different staffing needs. Larger interactive sessions can have weaker feedback at similar staffing levels. There are site differences, an Eastbank midyear decline, and a Brookfield improvement after the first quarter. Noise, small survey groups, missingness, and overlapping site results prevent perfect separation.

The underlying seasonal demand weights favor some autumn months, but realized monthly results are noisy. One year is enough to describe within-year variation, not to establish a recurring seasonal pattern. Do not insist that participants find an identical seasonal effect at every site.

The construction reflects a teaching scenario, not calibrated healthcare evidence. Hypotheses such as understaffing remain hypotheses in the student analysis. Observational associations do not demonstrate that extra staffing will cause an improvement.

## Cleaning key

There are 249 intentional cell changes across 205 rows, in addition to the 192 structurally absent feedback fields on the 96 undelivered sessions. There are no duplicated session IDs or copied rows.

| Issue family | Changed cells |
|---|---:|
| Missing entries | 100 |
| Mixed date formats | 26 |
| Inconsistent category formatting | 55 |
| Numeric values with unit, scale, or percent suffixes | 44 |
| Impossible, out-of-period, or out-of-range entries | 19 |
| Status/attendance or status/feedback contradictions | 5 |

`data_quality_key.csv` identifies each changed cell and its reference value. Do not distribute this key before the exercise. The reference cleaner does not read it.

Use three different ideas when teaching missingness:

1. A zero count can be a valid observation.
2. A blank outcome on an undelivered session is not applicable.
3. A blank outcome on a completed session is missing feedback.

The reference cleaner standardizes recognizable formats, converts invalid entries to missing, and quarantines contradictory attendance. It does not recover unrecoverable values from the answer key. Numeric feature imputation for modeling is learned from training data only. Satisfaction labels are never imputed.

The recording limits of 80 total volunteer person-hours and 60 participants are explicit rules of this fictional exercise, not universal limits for real telehealth services. Fractional participant counts are invalid. A volunteer-hour value with an `hrs` suffix can be parsed, while a value of 240 cannot be guessed to mean 2.40.

Missingness is not entirely random: Hillcrest and lower-satisfaction sessions have higher probabilities of missing feedback. Available-case means can therefore be biased. Small response groups also make problem-addressed percentages noisy. No survey-response counts are provided, so participant-weighted satisfaction or a pooled addressed percentage cannot be reconstructed.

## Pearson correlation checks

Pearson correlation is a descriptive statistical measure, not an ML model. The following checks use completed sessions and pairwise available cleaned values:

| Pair | n | Pearson r |
|---|---:|---:|
| Volunteer hours and attendance | 465 | 0.154 |
| Hours per participant and satisfaction | 428 | 0.521 |
| Satisfaction and problem-addressed percentage | 436 | 0.427 |

Use scatterplots and within-type comparisons. A weak pooled correlation between total hours and attendance partly reflects different session types. Do not encode site names as 1–6 and correlate those arbitrary numbers. The p-values in the reproducibility output use ordinary independent-row assumptions; repeated sessions within sites violate that simplification. Teach the coefficients descriptively rather than interpreting those p-values as population evidence.

## Model validation

Target: participant_satisfaction among completed sessions with a valid date and recorded satisfaction. Training set: January–September (320 sessions). Holdout: October–December (138 sessions). Rows with unavailable targets or dates are excluded; missing numeric predictors are imputed using training medians.

Features: site, session_type, month, volunteer_hours, participant_count, and hours_per_participant. Categorical fields are one-hot encoded. No session IDs, paired feedback outcome, answer-key fields, or generator-only variables are used. The same features and split are supplied to each model.

| Model | Holdout MAE, rating points | Holdout R² |
|---|---:|---:|
| Training-mean baseline | 0.517 | -0.021 |
| Ridge regression | 0.313 | 0.534 |
| Random Forest | 0.289 | 0.657 |
| XGBoost | 0.281 | 0.695 |

These are checks on this fixed synthetic exercise, not evidence of real-world model performance. The learner models were not tuned against this holdout. Results may vary slightly across library versions. With only 138 holdout sessions, the small difference between the two tree models does not establish general superiority. Site and month effects can still be confounded with unobserved factors. Cross-validation, if added, belongs within the training period; preserve the final quarter for evaluation.

This is retrospective outcome modeling: actual volunteer hours and attendance are not available before delivery. If students instead predict cancellations before a session starts, use only information known beforehand, such as site, date, and session_type. Otherwise zero attendance and unavailable feedback create leakage.

Optional extension: use participant_problem_addressed as a separate regression target or classify whether a session reaches a stated workshop threshold, such as at least 80%. Such a threshold is a teaching choice, not a medical standard. That task has not been benchmarked here.

## Files and reproducibility

- `telehealth_sessions_reference.csv`: original synthetic values before recording errors. It is an answer key, not a cleaned dataset recoverable from the participant export.
- `telehealth_sessions_cleaned.csv`: one defensible cleaned version of the participant export. Missing values remain where the raw record cannot establish a valid value.
- `data_quality_key.csv`: cell-level changes and reference values.
- `site_summary.csv`, `monthly_summary.csv`: observed-data summaries. Monthly tables exclude undated records; annual site summaries retain them.
- `pearson_correlations.csv`, `model_validation.csv`, `validation_results.json`: reproducible checks.
- `clean_and_check.py`: cleaning and validation code. It reads only the participant export and writes the checks above.

To reproduce, extract the complete facilitator bundle, install the packages in `requirements.txt`, and run `python facilitator/clean_and_check.py` from the extracted folder. Use Python 3.12 or a compatible environment. On macOS, XGBoost may require the OpenMP runtime; a standard Linux notebook environment avoids that platform-specific setup.

Suggested sequence: 15 minutes inspecting/cleaning, 20 minutes comparing sites and trends, 15 minutes on correlations, 20 minutes on optional modeling, and 10 minutes presenting visit recommendations. Add a 10-minute introduction for a 90-minute workshop.
